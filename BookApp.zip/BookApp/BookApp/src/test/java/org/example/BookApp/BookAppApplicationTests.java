package org.example.BookApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
