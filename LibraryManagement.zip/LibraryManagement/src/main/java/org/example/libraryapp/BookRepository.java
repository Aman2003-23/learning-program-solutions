package org.example.libraryapp;

public class BookRepository {
    public void saveBook(String title) {
        System.out.println("Book saved: " + title);
    }
}
